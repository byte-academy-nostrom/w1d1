def my_loop(x):
    # write your code here
    # you'll have to delete "pass"
    pass


def my_reverse_loop(y):
    # write your code here
    # you'll have to delete "pass"
    pass

print (my_loop(10))
